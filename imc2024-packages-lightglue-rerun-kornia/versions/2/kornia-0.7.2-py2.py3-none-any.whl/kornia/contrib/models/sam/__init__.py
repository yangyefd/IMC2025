from kornia.contrib.models.sam.model import Sam, SamConfig, SamModelType
