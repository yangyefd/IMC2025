from kornia.contrib.models.structures import Prompts, SegmentationResults
