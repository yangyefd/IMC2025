from kornia.geometry.line import ParametrizedLine

# NOTE: for now lets make an alias
# TODO: add more functionality and semantics for graphics stuff
Ray = ParametrizedLine
