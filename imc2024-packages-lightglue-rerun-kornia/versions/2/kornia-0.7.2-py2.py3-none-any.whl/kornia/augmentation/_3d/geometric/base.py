from kornia.augmentation._3d.base import RigidAffineAugmentationBase3D


class GeometricAugmentationBase3D(RigidAffineAugmentationBase3D):
    pass
