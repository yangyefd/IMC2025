from .dinov2 import vit_large

__all__ = [
    "vit_large",
]
