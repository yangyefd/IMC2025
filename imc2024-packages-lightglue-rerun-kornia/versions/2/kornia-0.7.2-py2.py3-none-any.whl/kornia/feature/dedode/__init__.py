from .dedode import DeDoDe

__all__ = ["DeDoDe"]
