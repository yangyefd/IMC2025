from .sold2 import SOLD2
from .sold2_detector import SOLD2_detector
